package com.hollowburst.server;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Small helpers for particles and sounds, so the sequences stay readable. */
final class Fx {
    static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(1.0f, 0.08f, 0.12f), 1.6f);
    static final DustParticleOptions RED_BIG = new DustParticleOptions(new Vector3f(1.0f, 0.08f, 0.12f), 3.2f);
    static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.10f, 0.35f, 1.0f), 1.6f);
    static final DustParticleOptions BLUE_BIG = new DustParticleOptions(new Vector3f(0.10f, 0.35f, 1.0f), 3.2f);
    static final DustParticleOptions PURPLE = new DustParticleOptions(new Vector3f(0.70f, 0.10f, 1.0f), 1.8f);
    static final DustParticleOptions PURPLE_BIG = new DustParticleOptions(new Vector3f(0.70f, 0.10f, 1.0f), 3.8f);

    /** A single particle at an exact position. */
    static void one(ServerLevel l, ParticleOptions o, Vec3 p) {
        l.sendParticles(o, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    /** A cloud of particles around a point. */
    static void burst(ServerLevel l, ParticleOptions o, Vec3 p, int count, double spread, double speed) {
        l.sendParticles(o, p.x, p.y, p.z, count, spread, spread, spread, speed);
    }

    /** A flat ring of particles that fly outward (count 0 means the offset is the velocity). */
    static void ring(ServerLevel l, ParticleOptions o, Vec3 c, int points, double speed) {
        for (int i = 0; i < points; i++) {
            double a = (Math.PI * 2.0 * i) / points;
            l.sendParticles(o, c.x, c.y, c.z, 0, Math.cos(a), 0.02, Math.sin(a), speed);
        }
    }

    static void sound(ServerLevel l, Vec3 p, String id, float volume, float pitch) {
        SoundEvent se = BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse(id));
        if (se != null) {
            l.playSound(null, p.x, p.y, p.z, se, SoundSource.PLAYERS, volume, pitch);
        }
    }

    static Vec3 randomUnit(RandomSource r) {
        Vec3 v = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian());
        return v.lengthSqr() < 1.0E-6 ? new Vec3(0, 1, 0) : v.normalize();
    }

    private Fx() {}
}
