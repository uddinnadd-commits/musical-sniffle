package com.hollowburst.client;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;

import java.util.List;

/** Runtime state of the cutscene currently playing (client only). */
public final class CutscenePlayer {
    private static CutsceneDef current;
    private static long startNanos;
    private static CameraType previousCamera;
    private static int appliedCut = -1;

    public static void start(CutsceneDef def) {
        Minecraft mc = Minecraft.getInstance();
        if (current == null) {
            previousCamera = mc.options.getCameraType();
        }
        current = def;
        startNanos = System.nanoTime();
        appliedCut = -1;
        applyCuts(mc, 0L);
    }

    public static CutsceneDef def() {
        return current;
    }

    public static boolean active() {
        return current != null;
    }

    public static long elapsedMs() {
        return (System.nanoTime() - startNanos) / 1_000_000L;
    }

    /** True while the player should not be able to move or swing. */
    public static boolean inputLocked() {
        return current != null && elapsedMs() < current.freezeMs;
    }

    public static void tick(Minecraft mc) {
        if (current == null) return;
        if (mc.player == null || mc.level == null || mc.player.isDeadOrDying()) {
            stop(mc);
            return;
        }
        long t = elapsedMs();
        if (t >= current.durationMs) {
            stop(mc);
            return;
        }
        applyCuts(mc, t);
    }

    private static void applyCuts(Minecraft mc, long t) {
        List<CutsceneDef.Cut> cuts = current.cuts;
        int idx = -1;
        for (int i = cuts.size() - 1; i >= 0; i--) {
            if (cuts.get(i).at() <= t) {
                idx = i;
                break;
            }
        }
        if (idx >= 0 && idx != appliedCut) {
            appliedCut = idx;
            mc.options.setCameraType(cuts.get(idx).camera());
        }
    }

    public static void stop(Minecraft mc) {
        if (previousCamera != null) {
            mc.options.setCameraType(previousCamera);
        }
        current = null;
        previousCamera = null;
        appliedCut = -1;
    }

    private CutscenePlayer() {}
}
