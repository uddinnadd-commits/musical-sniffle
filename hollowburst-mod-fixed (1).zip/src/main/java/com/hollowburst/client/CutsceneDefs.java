package com.hollowburst.client;

import com.hollowburst.CutsceneType;
import net.minecraft.client.CameraType;

import static com.hollowburst.client.CutsceneDef.BLACK;
import static com.hollowburst.client.CutsceneDef.INVERT;
import static com.hollowburst.client.CutsceneDef.WHITE;

/**
 * The three cutscenes. All times are milliseconds. The server runs the matching gameplay
 * on a 50 ms tick clock, so the big impact frames line up with the server explosions:
 *   BURST: explosion at 1200 ms      SWORD: slash at 2000 ms      MACE: impact at 3900 ms
 * Tweak anything here: timings, subtitles (lang keys), camera cuts, zoom, shake, roll.
 */
public final class CutsceneDefs {

    private static final int RED = 0xFF4455;
    private static final int BLUE = 0x5CA8FF;
    private static final int PURPLE = 0xC27CFF;
    private static final int WHITE_TEXT = 0xFFFFFF;

    public static CutsceneDef get(CutsceneType type) {
        return switch (type) {
            case BURST -> burst();
            case SWORD -> sword();
            case MACE -> mace();
        };
    }

    // ------------------------------------------------------------------ C key: Reversal: Red

    private static CutsceneDef burst() {
        return new CutsceneDef(2900)
                .freeze(1800)
                .cut(0, CameraType.THIRD_PERSON_FRONT)
                .cut(1250, CameraType.THIRD_PERSON_BACK)
                .fov(Curves.keys(
                        0, 1.0,
                        1100, 0.52,
                        1180, 0.45,
                        1260, 1.50,
                        2000, 1.15,
                        2900, 1.0))
                .roll(Curves.keys(
                        0, 0,
                        900, 0,
                        1150, -6,
                        1300, 9,
                        2000, 0))
                .shake(Curves.keys(
                        0, 0,
                        500, 0,
                        1150, 0.9,
                        1160, 3.2,
                        1700, 1.3,
                        2500, 0))
                .tint(0xFF1020, Curves.keys(
                        0, 0,
                        800, 0.10,
                        1150, 0.28,
                        1300, 0.0,
                        2900, 0.0))
                .flash(1200, 450, 0xFFFFFF)
                .impact(1110, 55, 11, INVERT, WHITE, BLACK)
                .impact(1270, 60, 12, INVERT, BLACK)
                .sub(200, 1000, "subtitle.hollowburst.red_1", WHITE_TEXT, 1.5f, false)
                .sub(900, 1950, "subtitle.hollowburst.red_2", RED, 1.8f, true);
    }

    // ------------------------------------------------------------------ sword hit: Lapse: Blue

    private static CutsceneDef sword() {
        return new CutsceneDef(3900)
                .freeze(3300)
                .cut(0, CameraType.THIRD_PERSON_BACK)
                .cut(1900, CameraType.THIRD_PERSON_FRONT)
                .cut(2700, CameraType.THIRD_PERSON_BACK)
                .fov(Curves.keys(
                        0, 1.0,
                        1240, 0.72,
                        1260, 0.60,
                        1900, 0.60,
                        2000, 1.50,
                        2400, 1.15,
                        3900, 1.0))
                .roll(Curves.keys(
                        0, 0,
                        1250, 4,
                        2000, -10,
                        2100, 12,
                        2800, 0))
                .shake(Curves.keys(
                        0, 0,
                        800, 0.4,
                        1250, 0.9,
                        1260, 2.5,
                        1500, 0.5,
                        1990, 0.5,
                        2000, 4.0,
                        2500, 1.2,
                        3300, 0))
                .tint(0x1A5CFF, Curves.keys(
                        0, 0,
                        600, 0.18,
                        1250, 0.28,
                        1900, 0.30,
                        2000, 0.0,
                        3900, 0.0))
                .flash(1250, 250, 0xBBDDFF)
                .flash(2000, 450, 0xE8F4FF)
                .impact(1245, 50, 21, INVERT, WHITE)
                .impact(1990, 45, 22, INVERT, WHITE, BLACK, INVERT, WHITE)
                .impact(2160, 60, 23, BLACK, INVERT)
                .sub(150, 1150, "subtitle.hollowburst.blue_1", WHITE_TEXT, 1.5f, false)
                .sub(1150, 1950, "subtitle.hollowburst.blue_2", BLUE, 1.8f, true)
                .sub(2500, 3500, "subtitle.hollowburst.blue_3", WHITE_TEXT, 1.5f, false);
    }

    // ------------------------------------------------------------------ mace hit: Hollow Purple

    private static CutsceneDef mace() {
        return new CutsceneDef(6300)
                .freeze(5100)
                .cut(0, CameraType.THIRD_PERSON_FRONT)
                .cut(1500, CameraType.THIRD_PERSON_BACK)
                .cut(4650, CameraType.THIRD_PERSON_FRONT)
                .fov(Curves.keys(
                        0, 1.0,
                        1500, 0.60,
                        1501, 0.95,
                        2900, 0.70,
                        2950, 0.55,
                        3880, 0.45,
                        3890, 1.90,
                        4400, 1.30,
                        4650, 1.00,
                        4651, 0.65,
                        5600, 0.70,
                        6300, 1.0))
                .roll(Curves.keys(
                        0, 0,
                        1500, -3,
                        2900, 5,
                        3100, 0,
                        3880, -12,
                        4000, 10,
                        4400, -4,
                        5000, 0))
                .shake(Curves.keys(
                        0, 0,
                        1500, 0.3,
                        2900, 1.2,
                        2910, 3.5,
                        3880, 1.5,
                        3890, 6.0,
                        4300, 3.0,
                        5000, 0.6,
                        5600, 0))
                .tint(0x8A2BE2, Curves.keys(
                        0, 0,
                        2900, 0.0,
                        3050, 0.25,
                        3880, 0.38,
                        3900, 0.0,
                        6300, 0.0))
                .flash(2950, 500, 0xE0B0FF)
                .flash(3890, 700, 0xFFFFFF)
                .impact(2940, 60, 31, INVERT, WHITE, BLACK)
                .impact(3880, 50, 32, WHITE, BLACK, INVERT, WHITE, BLACK, INVERT, WHITE, BLACK)
                .impact(4160, 60, 33, INVERT, BLACK)
                .sub(150, 1450, "subtitle.hollowburst.purple_1", WHITE_TEXT, 1.5f, false)
                .sub(1600, 3000, "subtitle.hollowburst.purple_2", WHITE_TEXT, 1.4f, false)
                .sub(3050, 3900, "subtitle.hollowburst.purple_3", PURPLE, 2.0f, true)
                .sub(4700, 5700, "subtitle.hollowburst.purple_4", WHITE_TEXT, 1.5f, false);
    }

    private CutsceneDefs() {}
}
